/**
 * Die Klasse Zeitangabe soll bei diesem Projekt zur Generierung neuer Objekte des Zeitangabe-Typs verwendet werden können. Die Klasse besitzt verschiedene Attribute, die die einzelnen Objekte dieser Klasse characteriesieren. Im Kontekt des Projektes Datumsverwaltung soll die Klasse zur Erzeugung einzelner Zeitangaben dienen, beziehungsweise einen zeitpuk darstellen. Diese Generierten Objekte können dann einen gespeicherten zeitpunkt durch verschiedenen Rechoperationen  verändern. Ein Objekt dieser Klasse kann über verschiedene Konstruktoren generiert werden. Übergeben werden müssen entweder die Parameter int pSekunden, int pMinuten, int pStunden, int pTage, int pMonate, int pJahre, die für die Gleichnamigen Attribute stehen oder ein String der die Daten der Zeitangabe enthält. Die Werte der Attribute werden bei Erzeugung eines Objektes automatisch auf die der übergebenen Parameter gesetzt. 
 */
public class Zeitangabe {
    private int sekunden;
    private int minuten;
    private int stunden; 
    private int tage; 
    private int monate; 
    private int jahre;

    /**
     * Erzeugt ein neues Objekt vom Typ der Klasse Zeitangabe und gibt dieses zurück. Als Parameter muss int pSekunden, int pMinuten, int pStunden, int pTage, int pMonate, int pJahre übergeben werden. Die Übergebenen Parameter werden automatisch in dem entsprechenden Attribut des neuen Objektes gespeichert.
     */
    public Zeitangabe(int pSekunden, int pMinuten, int pStunden, int pTage, int pMonate, int pJahre){
        this.setJahre(pJahre);
        this.setMonate(pMonate);
        this.setTage(pTage);
        this.setStunden(pStunden);
        this.setMinuten(pMinuten);
        this.setSekunden(pSekunden);
    }

    /**
     * Erzeugt ein neues Objekt vom Typ der Klasse Zeitangabe und gibt dieses zurück. Als Parameter muss ein String angebenen werden der das Datum nach dem Format TT.MM.JJ hh:mm enthält.
     */
    public Zeitangabe(String pText){
        boolean isPM = pText.endsWith("pm");
        pText = this.bereinigeAllesWasKeineZahlIst(pText);
        
        this.setJahre(this.StringZuIntUmwandeln(pText.substring(4,8)));
        this.setMonate(this.StringZuIntUmwandeln(pText.substring(2, 4)));
        this.setTage(this.StringZuIntUmwandeln(pText.substring(0, 2)));
        if(pText.length() > 8){
            if(isPM){
                this.setStunden(this.StringZuIntUmwandeln(pText.substring(8, 10))+12);
            } else {
                this.setStunden(this.StringZuIntUmwandeln(pText.substring(8, 10)));
            }
            this.setMinuten(this.StringZuIntUmwandeln(pText.substring(10, 12)));
            if(pText.length() > 12){
                this.setSekunden(this.StringZuIntUmwandeln(pText.substring(12, 14)));
            } else {
                this.setSekunden(0);
            }
        } else {
            this.setStunden(0);
            this.setMinuten(0);
            this.setSekunden(0);
        }
    }

    /**
     * Mit dieser Methode kann man den Wert von Sekunden ändern. Das ist ein Attribut der Klasse Zeitangabe. Der neue Wert für dieses Attribut wird mit einem Paramter mit dem Namen pSekunden übergeben.
     */
    public void setSekunden(int pSekunden){
        int neu = pSekunden;
        while(neu < 0){
            neu += 60;
            this.setMinuten(this.getMinuten()-1);
        }
        this.setMinuten(this.getMinuten()+(neu/60));
        this.sekunden = neu%60;
    }

    /**
     * Ist die Getter Methode für das Attribute Sekunden. So kann der Wert von dem Attribut Sekunden der Klasse Zeitangabe ausgelesen und woanders verwendet werden. 
     */
    public int getSekunden(){ 
        return this.sekunden;
    }

    /**
     * Mit dieser Methode kann man den Wert von Minuten ändern. Das ist ein Attribut der Klasse Zeitangabe. Der neue Wert für dieses Attribut wird mit einem Paramter mit dem Namen pMinuten übergeben.
     */
    public void setMinuten(int pMinuten){
        int neu = pMinuten;
        while(neu < 0){
            neu += 60;
            this.setStunden(this.getStunden()-1);
        }
        this.setStunden(this.getStunden()+(neu/60));
        this.minuten = neu%60;
    }

    /**
     * Ist die Getter Methode für das Attribute Minuten. So kann der Wert von dem Attribut Minuten der Klasse Zeitangabe ausgelesen und woanders verwendet werden. 
     */
    public int getMinuten(){ 
        return this.minuten;
    }

    /**
     * Mit dieser Methode kann man den Wert von Stunden ändern. Das ist ein Attribut der Klasse Zeitangabe. Der neue Wert für dieses Attribut wird mit einem Paramter mit dem Namen pStunden übergeben.
     */
    public void setStunden(int pStunden){
        int neu = pStunden;
        while(neu < 0){
            neu += 24;
            this.setTage(this.getTage()-1);
        }
        this.setTage(this.getTage()+(neu/24));
        this.stunden = neu%24;
    }

    /**
     * Ist die Getter Methode für das Attribute Stunden. So kann der Wert von dem Attribut Stunden der Klasse Zeitangabe ausgelesen und woanders verwendet werden. 
     */
    public int getStunden(){ 
        return this.stunden;
    }

    /**
     * Mit dieser Methode kann man den Wert von Tage ändern. Das ist ein Attribut der Klasse Zeitangabe. Der neue Wert für dieses Attribut wird mit einem Paramter mit dem Namen pTage übergeben.
     */
    public void setTage(int pTage){
        int neu = pTage;
        while(neu < 0){
            int monattage = this.TageEinesMonatsErmitteln(this.getMonate()-1, this.getJahre());
            neu += monattage;
            this.setMonate(this.getMonate()-1);
        }
        boolean perfekt = false;
        while(perfekt == false){
            int monattage = this.TageEinesMonatsErmitteln(this.getMonate(), this.getJahre());
            if(neu < monattage){
                perfekt = true;
            } else {
                neu -= monattage;
                this.setMonate(this.getMonate()+1);
            }
        }
        this.tage = neu;
    }

    /**
     * Ist die Getter Methode für das Attribute Tage. So kann der Wert von dem Attribut Tage der Klasse Zeitangabe ausgelesen und woanders verwendet werden. 
     */
    public int getTage(){ 
        return this.tage;
    }

    /**
     * Mit dieser Methode kann man den Wert von Monate ändern. Das ist ein Attribut der Klasse Zeitangabe. Der neue Wert für dieses Attribut wird mit einem Paramter mit dem Namen pMonate übergeben.
     */
    public void setMonate(int pMonate){
        int neu = pMonate;
        while(neu < 0){
            neu += 12;
            this.setJahre(this.getJahre()-1);
        }
        this.setJahre(this.getJahre()+(neu/12));
        this.monate = neu%12;
    }

    /**
     * Ist die Getter Methode für das Attribute Monate. So kann der Wert von dem Attribut Monate der Klasse Zeitangabe ausgelesen und woanders verwendet werden. 
     */
    public int getMonate(){ 
        return this.monate;
    }

    /**
     * Mit dieser Methode kann man den Wert von Jahre ändern. Das ist ein Attribut der Klasse Zeitangabe. Der neue Wert für dieses Attribut wird mit einem Paramter mit dem Namen pJahre übergeben.
     */
    public void setJahre(int pJahre){
        this.jahre = pJahre; 
    }

    /**
     * Ist die Getter Methode für das Attribute Jahre. So kann der Wert von dem Attribut Jahre der Klasse Zeitangabe ausgelesen und woanders verwendet werden. 
     */
    public int getJahre(){ 
        return this.jahre;
    }
    
    /**
     * Folgende Methoden erhöhen Jewails den Wert des im namen der mEthode genannten Attributes und berücksichtigen dabei automatisch die Darstellung des Datums in allen Werten.
     */
    public void SekundenErhoehen(int anzahl){
        this.setSekunden(this.getSekunden()+anzahl);
    }
    public void MinutenErhoehen(int anzahl){
        this.setMinuten(this.getMinuten()+anzahl);
    }
    public void StundenErhoehen(int anzahl){
        this.setStunden(this.getStunden()+anzahl);
    }
    public void TageErhoehen(int anzahl){
        this.setTage(this.getTage()+anzahl);
    }
    public void MonateErhoehen(int anzahl){
        this.setMonate(this.getMonate()+anzahl);
    }
    public void JahreErhoehen(int anzahl){
        this.setJahre(this.getJahre()+anzahl);
    }
    
    /**
     * Erhöht den Wert des Datums eines Objektes um den Wert eines als Paramter übergebenen Datumobjektes.
     */
    public void mitAnderemDatumErhöhen(Zeitangabe pDatum){
        this.SekundenErhoehen(pDatum.getSekunden());
        this.MinutenErhoehen(pDatum.getMinuten());
        this.StundenErhoehen(pDatum.getStunden());
        this.TageErhoehen(pDatum.getTage());
        this.MonateErhoehen(pDatum.getMonate());
        this.JahreErhoehen(pDatum.getJahre());
    }
    public void mitAnderemDatumErniedrigen(Zeitangabe pDatum){
        this.SekundenErhoehen(-pDatum.getSekunden());
        this.MinutenErhoehen(-pDatum.getMinuten());
        this.StundenErhoehen(-pDatum.getStunden());
        this.TageErhoehen(-pDatum.getTage());
        this.MonateErhoehen(-pDatum.getMonate());
        this.JahreErhoehen(-pDatum.getJahre());
    }

    /**
     * Ermittelt die Anzahl Tage die ein als Parameter übergebener Monat in dem ebenfals als Parameter übergebenen Jahres hat.
     */
    private int TageEinesMonatsErmitteln(int monat, int jahr){
        while(monat < 0){
            monat += 12;
            jahr -= 1;
        }
        if(monat == 0 || monat == 2 || monat == 4 || monat == 6 || monat == 7 || monat == 9 || monat == 11){
            return 31;
        } else if(monat == 3 || monat == 5 || monat == 8 || monat == 10){
            return 30;
        } else if(monat == 1){
            //Alle 4 jahre gibt es ein Schaltjahr, mit Ausnahme jedes 100te Jahr. Jedes 400te jahr ist trotzdem ein Schaltjahr, obwohl es auch in der 100ter Reihe ist.
            if((jahr%4 == 0 && jahr%100 != 0) || jahr%400 == 0){
                return 29;
            } else {
                return 28;
            }
        }
        //Wenn ein ungültiger Monat übermittelt wurde
        return -1;
    }
    /**
     * Gibt die Ziffer, die ein ASCII Code darstellt, als Integer zurück. Handelt es sich um keine Ziffer wird -1 zurückgegeben.
     */
    public int ASCIICodeToInt(char c){
        if(c == 48) return 0;
        if(c == 49) return 1;
        if(c == 50) return 2;
        if(c == 51) return 3;
        if(c == 52) return 4;
        if(c == 53) return 5;
        if(c == 54) return 6;
        if(c == 55) return 7;
        if(c == 56) return 8;
        if(c == 57) return 9;
        return -1;
    }
    /**
     * Gibt einen Integer als String zurück. Dabei muss eine bestimmte Anzahl Stellen übergeben werden, die der neue String haben muss. Ist die Zahl zu klein, werden Nullen aufgefüllt. Ist er zu lang werden Zahlen entfernt.
     */
    private String IntZuStringMitAnzahlStellen(int integer, int stellen){
        String neu = ""+integer;
        while(neu.length() < stellen){
            neu = "0"+neu;
        }
        return neu;
    }
    /**
     * Rechnet eine übergebene Zahl hoch einer anderen ebenfals übergebenen Zahl. Es muss immer mindestens hoch 1 Gerechnet werden, damit die Funktion funktioniert.
     */
    private int HochXRechnen(int z, int x){
        int n = z;
        for(int i = 0; i < x-1; i++){
            n = n*z;
        }
        return n;
    }
    /**
     * Gibt einen String als Integer zurück.
     */
    private int StringZuIntUmwandeln(String text){
        int neu = 0;
        for(int i = 0; i < text.length(); i++){
            neu += this.ASCIICodeToInt(text.charAt(i))*this.HochXRechnen(10, text.length()-i);
        }
        return neu/10;
    }
    /**
     * Entfernt alle Zeichen aus einen String die keine Ziffern sind. Damit das Format eines Datums und einer Urzeit passt, müssen alle durch andere Zeichen getrennte Ziffernpaare eine bestimmte Anzahl stellen haben. Ist diese nicht erreicht werden Nullen aufgefüllt. 
     */
    private String bereinigeAllesWasKeineZahlIst(String text){
        text = "  "+text+"; ";
        String neu = "";
        String test = "";
        int wert = 1;
        for (int i = 0; i < text.length(); i++){
            if((int)text.charAt(i) >= 47 && (int)text.charAt(i) <= 57){
                test += text.charAt(i)+"";
            } else if(test.length() > 0){
                if(wert == 3){
                    while(test.length() != 4) {
                        test = "0"+test;
                    }
                    neu += test.substring(test.length()-4, test.length());
                } else {
                    if(test.length() == 1) {
                        test = "0"+test;
                    }
                    neu += test.substring(test.length()-2, test.length());
                }
                test = "";
                wert++;
            }
        }
        return neu;
    }
    
    //Konvertieungsfunktion
    public String alsDeutscheZeit(){
        return this.IntZuStringMitAnzahlStellen(this.getTage(), 2)+"."+this.IntZuStringMitAnzahlStellen(this.getMonate(), 2)+"."+this.IntZuStringMitAnzahlStellen(this.getJahre(), 4)+" "+this.IntZuStringMitAnzahlStellen(this.getStunden(), 2)+":"+this.IntZuStringMitAnzahlStellen(this.getMinuten(), 2)+":"+this.IntZuStringMitAnzahlStellen(this.getSekunden(), 2);
    }
    public String alsEnglischeZeit(){
        if(this.getStunden()/12 == 0){
            return this.IntZuStringMitAnzahlStellen(this.getTage(), 2)+"."+this.IntZuStringMitAnzahlStellen(this.getMonate(), 2)+"."+this.IntZuStringMitAnzahlStellen(this.getJahre(), 4)+" "+this.IntZuStringMitAnzahlStellen(this.getStunden()%12, 2)+":"+this.IntZuStringMitAnzahlStellen(this.getMinuten(), 2)+":"+this.IntZuStringMitAnzahlStellen(this.getSekunden(), 2)+" am";
        } else {
            return this.IntZuStringMitAnzahlStellen(this.getTage(), 2)+"."+this.IntZuStringMitAnzahlStellen(this.getMonate(), 2)+"."+this.IntZuStringMitAnzahlStellen(this.getJahre(), 4)+" "+this.IntZuStringMitAnzahlStellen(this.getStunden()%12, 2)+":"+this.IntZuStringMitAnzahlStellen(this.getMinuten(), 2)+":"+this.IntZuStringMitAnzahlStellen(this.getSekunden(), 2)+" pm";
        }
    }
    
    //Berechnungsfunktionen
    public Zeitangabe ZeitNachBestimmterZeit(Zeitangabe pZeit){
         return new Zeitangabe(this.getSekunden()+pZeit.getSekunden(), this.getMinuten()+pZeit.getMinuten(), this.getStunden()+pZeit.getStunden(), this.getTage()+pZeit.getTage(), this.getMonate()+pZeit.getMonate(), this.getJahre()+pZeit.getJahre());
    }
    public Zeitangabe ZeitVorBestimmterZeit(Zeitangabe pZeit){
         return new Zeitangabe(this.getSekunden()-pZeit.getSekunden(), this.getMinuten()-pZeit.getMinuten(), this.getStunden()-pZeit.getStunden(), this.getTage()-pZeit.getTage(), this.getMonate()-pZeit.getMonate(), this.getJahre()-pZeit.getJahre());
    }
    public Zeitangabe NotwendigeZeitBisZuAndererZeit(Zeitangabe pZeit){
         return new Zeitangabe(pZeit.getSekunden()-this.getSekunden(), pZeit.getMinuten()-this.getMinuten(), pZeit.getStunden()-this.getStunden(), pZeit.getTage()-this.getTage(), pZeit.getMonate()-this.getMonate(), pZeit.getJahre()-this.getJahre());
    }
    public Zeitangabe VergangeneZeitSeitAndererZeit(Zeitangabe pZeit){
         return new Zeitangabe(this.getSekunden()-pZeit.getSekunden(), this.getMinuten()-pZeit.getMinuten(), this.getStunden()-pZeit.getStunden(), this.getTage()-pZeit.getTage(), this.getMonate()-pZeit.getMonate(), this.getJahre()-pZeit.getJahre());
    }
    public Zeitangabe Zeitdifferenz(Zeitangabe pZeit){
        //Es muss geprüft werden, ob die Übergebene Zeit vor oder nach der aktuellen liegt.
        Zeitangabe neu = this.VergangeneZeitSeitAndererZeit(pZeit);
        if(neu.getJahre() < 0){
            neu = this.NotwendigeZeitBisZuAndererZeit(pZeit);
        }
        return neu;
    }
}